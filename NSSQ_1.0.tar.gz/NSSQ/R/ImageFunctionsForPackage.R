##################
#what's new#######
##################
#v1.1:
#04/07/2018:
#added commments/descriptions to the functions
#split spot segmentation into a single frame, a filtering and a frame-series version
#included the alwaysSegment function, that optimizes thresholding parameters to get a central object
#20/07/2018
#added bwlabel to filter_spots to make sure that spots are removed according to correct index
#v1.0:
#works with EBImage version 4.12.2
#28/02/2018:
#nuclear tracking starting from selection coordinates, instead of central object
#incremental decrease of maximum tracking distance until number of mappings is computationally feasible
#hole filling in nuclear segmentation
#stop of track construction, if mapping is NA
#20/08/2018:
#in readImageRegion now only add 1, if the output dimensions are even
#added a function for gap filling in mask series
#v1.3:
#13/11/2018:
#added a function to calculate the background as a tilted plane



library(EBImage)
library(plyr)


##################
#loading##########
##################
readMask<-function(files){
  #reads a (series of) mask image(s) and recovers object IDs; mask needs to be saved as a normalized tif image
  im<-readImage(files)
  if (length(dim(im))>2){
    im<-Image(apply(im,3,function(x)round(x*(length(unique(c(x)))-1))),dim = dim(im))
  } else im<-round(im*(length(unique(c(im)))-1))
}

##################
#image processing#
##################

subtractBG<-function(im,blur_width){
  #local background subtraction by subtraction of the blurred image, set zero at minimal value
  im<-im-gblur(im,sigma=blur_width) #make background uniform
  im<-im-min(im)
}
thresh_rad_border<-function(im,th_offset,min_rad,max_rad,border_filter=T){
  #the function applies a local threshold to im plus an offset, it filters out too small and border-touching objects
  #local background is determined by blurring with a brush size of the maximum nucleus size
  #im: image, th_offset: intensity offset segmented objects should have above the local background
  #min/max_rad: minimum and maximum radius the nuclei should have, border_filter: remove nuclei touching the borders of the image
  #threshold nuclei
  disc <- makeBrush(2*max_rad+1, "disc")
  disc <- disc / sum(disc)
  mask<-gblur(im>(filter2(im,disc)+th_offset),sigma = 3) #local threshold with offset, blurring and re-thresholding to bring up weak objects
  mask<-mask>(filter2(mask,disc)+th_offset)
  mask<-fillHull(bwlabel(mask))
  mask<-watershed( distmap(mask), 2) #segment adjacent nuclei
  #filter nuclei
  mask<-rmObjects(mask,which(computeFeatures.shape(mask)[,'s.radius.mean']<min_rad))
  if (border_filter==T) mask<-rmObjects(mask,unique(c(mask[1,],mask[,1],mask[dim(mask)[1],],mask[,dim(mask)[2]]))) #remove border touching objects
  mask
}

alwaysSegment<-function(im,th_offset_max,min_rad,max_rad,border_filter=T,max_iter=10){
  #modified version of thresh_rad_border that adjusts the offset until there is an object (inside min/max_rad) at center position
  #threshold nuclei
  th_offset<-th_offset_max
  for (i in 1:max_iter){
    disc <- makeBrush(2*max_rad+1, "disc")
    disc <- disc / sum(disc)
    mask<-gblur(im>(filter2(im,disc)+th_offset),sigma = 3) #local threshold with offset, blurring and re-thresholding to bring up weak objects
    mask<-mask>(filter2(mask,disc)+th_offset)
    mask<-fillHull(bwlabel(mask))
    mask<-watershed( distmap(mask), 2) #segment adjacent nuclei
    #filter nuclei
    mask<-rmObjects(mask,which(computeFeatures.shape(mask)[,'s.radius.mean']<min_rad))
    if (border_filter==T) mask<-rmObjects(mask,unique(c(mask[1,],mask[,1],mask[dim(mask)[1],],mask[,dim(mask)[2]]))) #remove border touching objects
    if (mask[round(dim(mask)[1]/2),round(dim(mask)[2]/2)]>0) break else th_offset<-0.8*th_offset
  }
  mask
}


spots_singleFrame<-function(mask_im,ref_im,quant=0.99){
  #segmentation of spots in the reference image inside the mask based on intensity quantiles
  #mask_im: nucleus mask, ref_im: reference image
  #spot_min/max: minimum and maximum spot area
  #quant: quantile used for segmentation
  threshold<-quantile(ref_im[as.logical(mask_im)],quant)
  #segment spot using quantile as threshold
  spot_mask<-ref_im>threshold
  spot_mask<-fillHull(bwlabel(spot_mask))
  spot_mask<-watershed( distmap(spot_mask), tolerance = 0.01)#separate neighbouring spots
  spot_mask<-dilate(spot_mask,kern = makeBrush(1,'disc'))
  #select objects inside the (extended) nucleus area
  spot_mask<-spot_mask*dilate(mask_im,makeBrush(shape='disc',size=7))
}
 


filter_spots<-function(spot_mask,spot_min,spot_max){
  #remove objects touching the borders or outside the spot_min/max range
  spot_mask<-bwlabel(spot_mask)
  spot_mask<-rmObjects(spot_mask,
                       c(which(computeFeatures.shape(spot_mask)[,1]<spot_min | computeFeatures.shape(spot_mask)[,1]>spot_max),
                         unique(c(spot_mask[1,],spot_mask[,1],spot_mask[dim(spot_mask)[1],]))), reenumerate = T)

}

spot_segment<-function(mask_im,ref_im,spot_min,spot_max,quant=0.99){
  #segmentation of spots in the reference image inside the mask based on intensity quantiles
  #mask_im: nucleus mask, ref_im: reference image
  #spot_min/max: minimum and maximum spot area
  #quant: quantile used for segmentation
  spot_mask_series<-Image(mapply(function(m,r)spots_singleFrame(mask_im = m,ref_im = r,quant = quant),getFrames(mask_im),getFrames(ref_im)),dim=dim(ref_im))
  spot_mask_series<-Image(apply(spot_mask_series,3,function(x)filter_spots(x,spot_min,spot_max)),dim=dim(spot_mask_series))
  #exclude spots from nuclear background
  nuc_mask_bg<-mask_im-spot_mask_series
  mask_series<-Image(c(spot_mask_series,nuc_mask_bg),dim = c(dim(spot_mask_series),2));
}

filterObjects<-function(x,ref,feature='s.radius.mean',min=20,max=40){
  #remove objects for which the specified feature is outside the min/max range
  feat_df<-cbind(computeFeatures.basic(x,ref),computeFeatures.shape(x))
  if (length(feature)==1) feat<-feat_df[,feature]
  if (length(feature)==2) feat<-feat_df[,feature[1]]/feat_df[,feature[2]]
  mask<-rmObjects(x,which(feat<min|feat>max))
  mask
}

##########
#tracking#
##########

track<-function(obj1,obj2,feature_id,max_track_dis){
  # the tracking function takes the matrix of xy positions of objects in image 1 and 2
  # created by the computeFeatures.moments function and maps the closest objects in both images
  # minimizing the sum of euclidean distances of specified features between all objects
  if (is.null(obj1)|is.null(obj2)) return(NA)
  pw_dist<-apply(obj1,1,function(x) apply(obj2,1,function(y)dist(rbind(x[feature_id],y[feature_id])))) #pairwise distances
  dim(pw_dist)<-c(dim(obj2)[1],dim(obj1)[1]) #order distance matrix such that frame1 corresponds to columns
  
  while (sum(pw_dist<max_track_dis)>25){ #apply stricter distance limit, until tracking is computationally feasible
    max_track_dis<-max_track_dis-1
  }
  pw_dist<-rbind(max_track_dis-1,pw_dist)
  pw_dist_th<-pw_dist<max_track_dis#logical matrix of distances below the maximum distance
  paths<-expand.grid(alply(pw_dist_th,2,function(x)which(x)))#create all possible mappings with distances within maximum,1:disappearance
  paths<-as.matrix(paths[apply(paths,1,function(x)(length(unique(x))+max(length(which(x==1))-1,0))==length(x)),])#remove mappings, if one object is mapped twice, do not remove 1s
  path_lengths<-as.matrix(apply(paths,1,function(x) sum(pw_dist[cbind(x,1:dim(pw_dist)[2])])))#sum of distances for each mapping
  path_lengths[apply(paths,1,function(x) sum(pw_dist[cbind(x,1:dim(pw_dist)[2])]>max_track_dis)>0)]<-NA #remove paths that contain distances above the tracking threshold max_track_dis
  bestMapping<-paths[which.min(path_lengths),]-1
  bestMapping 
}
followTrack<-function(firstObj,trackMap){
  #takes the mapping of objects between consecutive frames and creates a track from the selected object in the first frame
  id<-firstObj
  contin_track<-numeric(length = length(trackMap)+1)
  contin_track[1]<-id
  for (f in 1:(length(trackMap))){
    if (!is.na(trackMap[[f]][id])&trackMap[[f]][id]!=0){
      contin_track[f+1]<-trackMap[[f]][id]
      id<-trackMap[[f]][id]
      
    }else{
      contin_track[(f+1):length(contin_track)]<-NA
      break
    }
    
  }
  contin_track
}

twoWayTrack<-function(xy,feature_id,frame,select_coord,track_dist){
  #in the position List xy (from computeFeature.moment) track the object at the selection coordinates
  #in the selected frame both forwards and backwards in time
  #use specified features (e.g. x,y,area,major-axis,...) and maximum tracking distance for the tracking
  selectedObject<-which.min((xy[[frame]][,1]-select_coord[1])^2+(xy[[frame]][,2]-select_coord[2])^2)
  forward_map<-lapply(frame:(length(xy)-1),function(a)track(xy[[a]],xy[[a+1]],feature_id = feature_id,max_track_dis = track_dist)) #index of objects of xy in next frame, 0: disappears
  reverse_map<-lapply(frame:2,function(a)track(xy[[a]],xy[[a-1]],feature_id = feature_id,max_track_dis = track_dist))
  forward_track<-followTrack(selectedObject,forward_map)
  reverse_track<-rev(followTrack(selectedObject,reverse_map))
  nucTrack<-c(reverse_track,forward_track[-1])
}

cropPosition<-function(coords,im,new_x,new_y){
  #uses coordinates coords to crop the same region around this positions in all frames of the image series
  x_off<-floor(new_x/2)
  y_off<-floor(new_y/2)
  crop_coord_x<-c(pmax((round(coords[1]-x_off)),1),pmin((round(coords[1]+x_off)),dim(im)[1]))#limit corner positions to image area
  crop_coord_y<-c(pmax((round(coords[2]-y_off)),1),pmin((round(coords[2]+y_off)),dim(im)[2]))
  new_dim<-c(x_off*2+1,y_off*2+1)
  crop_coord_x<-c(min(dim(im)[1]-new_dim[1]+1,crop_coord_x[1]),max(new_dim[1],crop_coord_x[2]))#extend crop regions hitting the image edge on the other side
  crop_coord_y<-c(min(dim(im)[2]-new_dim[2]+1,crop_coord_y[1]),max(new_dim[2],crop_coord_y[2]))
  if (length(dim(im))==2) cropped<-Image(im[crop_coord_x[1]:crop_coord_x[2],crop_coord_y[1]:crop_coord_y[2]],dim=c(new_dim[1],new_dim[2])) else {
    cropped<-Image(unlist(sapply(getFrames(im),function(x)x[crop_coord_x[1]:crop_coord_x[2],crop_coord_y[1]:crop_coord_y[2]])),dim=c(new_dim[1],new_dim[2],dim(im)[3:length(dim(im))]))
  }
}

cropMovingObjects<-function(nTrack,xy,im,new_x,new_y){
  #crop image series around the changing coordinates of an object using an object coordinate list and a track for the ID of the object
  Image(mapply(function(t,x,i)cropPosition(x[t,1:2],i,new_x,new_y),nTrack,xy,getFrames(im)),dim = c(new_x+1,new_y+1,dim(im)[3]))
}

readImageRegion<-function(fileList,posList,new_x,new_y){
  #load only a fixed image region around the specified coordinates with dimensions new_x/_y from a series of image files
  new_x<-floor(new_x/2)*2+1 #add 1, if number is even
  new_y<-floor(new_y/2)*2+1
  im_out<-Image(dim = c(new_x,new_y,length(fileList)))
  if (is.null(dim(posList))) posList<-array(rep(posList,each=length(fileList)),dim = c(length(fileList),2))
  for (i in 1:length(fileList)){
    im<-readImage(fileList[i])
    im_out[,,i]<-cropPosition(coords = posList[i,],im = im,new_x = new_x,new_y = new_y)
  }
  im_out
}

projectionTracking<-function(mask,ref_im,quant_max,dilation_diam){
  #excludes all objects outside the brightest object in the maximum projection
  max_proj<-Image(apply(ref_im,c(1,2),max),dim=dim(ref_im)[1:2])
  max_mask<-bwlabel((max_proj>quantile(max_proj[as.logical(apply(mask,c(1,2),max))],quant_max))*apply(mask,c(1,2),max))
  max_mask<-rmObjects(max_mask,setdiff(unique(c(max_mask)),which.max(computeFeatures.basic(max_mask,max_proj)[,'b.mean'])))
  max_mask_dil<-dilate(max_mask,makeBrush(dilation_diam,shape = 'disc'))*apply(mask,c(1,2),max)
  Image(apply(mask,3,function(x)bwlabel(max_mask_dil*x)),dim = dim(mask))
}
  

selectMainSpot<-function(spot_series_mask,ref_im,track_dist,selection_frame){
  #tracks spots and selects the track with the brightest spot in selection frame
  #returns a mask series with only the tracked main spot
  spot_series_mask<-bwlabel(spot_series_mask)
  #extract all moment and shape features
  xy_full<-lapply(getFrames(spot_series_mask),function(x)cbind(computeFeatures.moment(x),computeFeatures.shape(x)))
  #select the brightes spot in selection frame
  brightestSpot<-which.max(computeFeatures.basic(x = spot_series_mask[,,selection_frame],ref = ref_im[,,selection_frame])[,1])
  #starting coordinates
  coords<-xy_full[[selection_frame]]
  current_spot<-brightestSpot
  if (is.null(coords)) return(NA)
  spotTracks<-list()
  spotTracks[[selection_frame]]<-brightestSpot
  #cycle over frames forward
  for (i in (selection_frame+1):length(xy_full)){
    if (is.null(xy_full[[i]])) {spotTracks[[i]]<-NA; next}
    if (length(xy_full[[i]][,1])==0) {spotTracks[[i]]<-NA; next}
    if (is.na(xy_full[[i]])) {spotTracks[[i]]<-NA; next}
    #track current spot in next frame according to euclidean distance of all features
    mapped_id<-track(coords,xy_full[[i]],feature_id = 1:11,max_track_dis = track_dist)[current_spot]
    if (mapped_id==0){spotTracks[[i]]<-NA; next}
    spotTracks[[i]]<-mapped_id
    current_spot<-mapped_id
    coords<-xy_full[[i]]
  }
  coords<-xy_full[[selection_frame]]
  current_spot<-brightestSpot
  if (is.null(coords)) return(NA)
  #cycle over frames backwards
  for (i in (selection_frame-1):1){
    if (is.null(xy_full[[i]])) {spotTracks[[i]]<-NA; next}
    if (length(xy_full[[i]][,1])==0) {spotTracks[[i]]<-NA; next}
    if (is.na(xy_full[[i]])) {spotTracks[[i]]<-NA; next}
    #track current spot in previous frame according to euclidean distance of all features
    mapped_id<-track(coords,xy_full[[i]],feature_id = 1:11,max_track_dis = track_dist)[current_spot]
    if (mapped_id==0){spotTracks[[i]]<-NA; next}
    spotTracks[[i]]<-mapped_id
    current_spot<-mapped_id
    coords<-xy_full[[i]]
  }
  #remove all objects that are not the tracked spot
  output_mask<-Image(mapply(function(x,y,im)rmObjects(im,setdiff(seq(1,length.out = length(y[,1])),x)),spotTracks,xy_full,getFrames(spot_series_mask)),dim = dim(spot_series_mask))
}

fillTrackGaps<-function(mask){
  #copy neighbouring mask into empty frames using the frame before (or the next frame,if the first is missing)
  framewithmask<-apply(mask,3,function(x)length(unique(c(x)))>1)
  emptyframes<-which(!framewithmask)
  copyframes<-emptyframes-1
  copyframes[copyframes<1]<-2
  if (length(emptyframes)>0) mask[,,emptyframes]<-mask[,,copyframes]
  mask
}

############
#corrections
############
correctBleach<-function(im){
  #fits an exponential decay with offset to the average intensity of each frame and uses the extracted parameters for the correction
  #the correction just adds the intensity on average lost by bleaching (addition, not multiplication); this is intended to avoid over-correction
  im_median<-apply(im,3,median)
  frame<-1:length(im_median)
  if (mean(head(im_median,5))-mean(tail(im_median,5))<=sd(im_median)) return(im) #if there is no downward trend return original
  bleach_df<-data.frame(frame,im_median)
  B<-min(im_median)
  A<-max(im_median)-B
  k<-(-log(0.5)/which.min(abs(im_median-(0.5*A+B)))) #estimate from half time
  init_param<-data.frame(A,B,k)
  tryCatch(expr = fit<-nls(formula = im_median ~ A*exp(-k*frame)+B,data = bleach_df,start = init_param,
                   control = nls.control(minFactor = 1e-8,maxiter = 1e5,warnOnly =T) ),finally = return(im))
  if (!fit$convInfo$isConv) return(im)
  k_bleach<-fit$m$getPars()['k']
  B_bleach<-fit$m$getPars()['B']
  A_bleach<-fit$m$getPars()['A']
  im_cor<-Image(mapply(function(m,f)m+B_bleach+A_bleach*(1-exp(-k_bleach*f)),getFrames(im),frame),dim = dim(im))
}

####################
#z-plane management#
####################

measureGradient<-function(im){
  #creates an image with gradient values for each pixel
  Gy<-matrix(c(-1,0,1,-1,0,1,-1,0,1),nrow = 3,ncol = 3)
  Gx<-matrix(c(-1,-1,-1,0,0,0,1,1,1),nrow = 3,ncol = 3)
  im_prewitt<-sqrt(filter2(im,Gx)^2+filter2(im,Gy)^2)
}

selectInFocus<-function(im1,im2,im3,mask){
  #selects the z position with the maximum gradient in the mask area (use central slice as im1, which will be preferred if equal)
  grad1<-mapply(function(x,m)computeFeatures.basic(x = m,ref = x)[,'b.mean'],getFrames(measureGradient(im1)),getFrames(mask))
  grad2<-mapply(function(x,m)computeFeatures.basic(x = m,ref = x)[,'b.mean'],getFrames(measureGradient(im2)),getFrames(mask))
  grad3<-mapply(function(x,m)computeFeatures.basic(x = m,ref = x)[,'b.mean'],getFrames(measureGradient(im3)),getFrames(mask))
  grad<-rbind(grad1,grad2,grad3)
  apply(grad,2,which.max)
}

##################
#manual selections
##################
selectPositions<-function(imSeries){
  #allows interactive selection of an arbitrary number of positions in each frame (correction of last selection)
  #displays each image of the series and asks for position selection and confirmation for saving or discarding this position
  posList<-data.frame()
  for (i in 1:dim(imSeries)[3]){
    action<-'d'
    print(display(normalize(imSeries[,,i])*1.5,method='raster'))
    while(action!='n' & action!='f'){
    position<-locator(1,type = 'p')
    action<-readline(paste0('saved positions: ',dim(posList)[1],' no position in this frame [n] delete last [d] save last [s] save and finish [f]: '))
    if (action=='s'|action=='f') {
      posList<-rbind(posList,cbind(i,position$x,position$y))
    }
    if (action=='d') next
    if (action=='n') break
    }
  }
  names(posList)<-c('frame','x','y')
  posList
}



######################
#measurements in ROIs#
######################

tiltedPlane<-function(mask,refIm){
  #calculate gradient of refIm intensities in mask area and create a background intensity image
  #that follows the local gradient (and intensity) in the mask region
  x_margin<-which(apply(mask,1,sum)>0)
  y_margin<-which(apply(mask,2,sum)>0)
  x_profile<-sapply(x_margin,function(x) mean(c(refIm[x,as.logical(mask[x,])])) )
  y_profile<-sapply(y_margin,function(y) mean(c(refIm[as.logical(mask[,y]),y])) )
  x_slope<-lm(x_profile~x_margin)$coefficients[2]
  y_slope<-lm(y_profile~y_margin)$coefficients[2]
  central_x<-round(length(x_profile)/2)
  central_y<-round(length(y_profile)/2)
  centralInt<-median(c(x_profile[c(central_x-1,central_x,central_x+1)],y_profile[c(central_y-1,central_y,central_y+1)]))
  intercept<-centralInt-x_slope*x_margin[central_x]-y_slope*y_margin[central_y]
  plane_im<-outer(1:dim(mask)[1],1:dim(mask)[2],function(x,y) intercept+x_slope*x+y_slope*y)
  plane_im[plane_im<0]<-0
  plane_im
}

